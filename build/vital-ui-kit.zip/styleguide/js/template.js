/*******************************************
 * Copyright 2017
 *
 * vital-ui-kit, v0.0.4
 * UI Kit for GSS Vital Family
 *
 * By Neil Lin (https://github.com/Neil-Lin),Evan Wu (https://github.com/evanwu-tw),YuRu Lee (https://github.com/YuRu-Lee),Laura Lee (https://github.com/l443018),Patric,CJies Tan (https://github.com/cjies)
 *
 * License: Galaxy Software Services Corporation | 叡揚資訊股份有限公司 版權所有 © 2016
 *
 ******************************************/
