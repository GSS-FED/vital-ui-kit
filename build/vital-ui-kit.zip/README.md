# Vital UI Kit

Vital UI Kit 使用簡單、輕量級、模組化的 UI library。 Vital UI Kit 不不僅整理了常用又實用的元件，而且每一項元素都經過設計師與工程師合力精雕細琢產生，讓您在實作上能輕易的應用，也兼顧設計性、互動性與易用性。

* 適合各系統畫面
* 整合了常用的前端框架
* 重視使用者經驗

<!-- TOC -->

- [Vital UI Kit](#vital-ui-kit)
  - [檔案結構](#檔案結構)
  - [Source Code 結構](#source-code-結構)
- [Ui kit 使用說明](#ui-kit-使用說明)
- [Browser Support](#browser-support)
- [Copyright and License](#copyright-and-license)

<!-- /TOC -->

## 檔案結構

```
dist                          所有 ui kit resources (css, js...)
├── css
│    ├── fonts
│    └── vital-ui-kit.css
├── js
│    ├── vital-ui-kit.js
│    └── vital-ui-kit.min.js
│
│
styleguide                   ui kit style guide, index.html entry
```

## Source Code 結構
```
src
├── base
├── components
├── scripts
├── structures
├── utils
├── _core.scss
└── vital-ui-kit.scss
```

# Ui kit 使用說明
 Vital UI Kit 提供了兩種使用方式，您可以依照喜好或是情況選擇適合您的方式開始應用。

1. 直接下載 Vital UI Kit

如果您不需要開發原始碼或是還不熟悉Sass，您可以使用此種方式，方便且快速就可以應用 Vital UI Kit 在您的產品或專案上。

2. 使用 Npm & Gulp 

Step 1. 在使用 Gulp 之前，請先至Vital UI Kit，利用版本控管工具 clone 整份檔案到您的本地端(建議使用Https)。

Step 2. 下載後，請打開您的終端機並且將路徑改成 Step 1.的資料夾，並輸入： `npm install`

這個動作我們會幫您建立 Vital UI Kit 所需要用到的工具：Node.js 與 Bower
您可以至Gulp,Node.js,NPM以及Bower進一步了解它們。

Step 3. 接著再執行
`npm start`

專案便會開始啟動！

別急，接下來記得在 Html 中引入
```
<link rel="stylesheet" href="./css/basic.css">
```
```
<script src="./js/jquery.min.js"></script>
<script src="./js/vital-ui-kit.js"></script>
```

# Browser Support

為了網頁技術的推進，以及為使用者帶來更好的體驗，瀏覽器支援度我們會專注在最新版的主流瀏覽器上。


# Copyright and License

